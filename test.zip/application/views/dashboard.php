<?php
	echo "Hello World";
?>
<a href="<?php echo site_url().'/account/logout'; ?>">Logout</a>
