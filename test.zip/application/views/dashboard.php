<?php
   
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>AdminLTE 2 | Starter</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/AdminLTE.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/skin-black.min.css">
    </head>
    <body class="hold-transition skin-black sidebar-mini">
        <div class="wrapper">
            
            <?php $this->load->view('include/header'); ?>
            <?php $this->load->view('include/aside'); ?>
            
            <div class="content-wrapper">
                <section class="content-header">
                    <h1>
                        DashBoard
                        <small>Control Panel</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-home"></i>Home</a></li>
                        <li class="active">Here</li>
                    </ol>
                </section>
                <section class="content">

                </section>
            </div>

            <?php $this->load->view('include/footer'); ?>

            <aside class="control-sidebar control-sidebar-dark">
                <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
                    <li class="active"><a href="#control-sidebar-home-tab" data-toggle="tab">Side Menu</a></li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <!-- Home tab content -->
                    <div class="tab-pane active" id="control-sidebar-home-tab">
                        <ul class="control-sidebar-menu">
                            <li><a href="#">Level 1</a></li>
                            <li><a href="#">Level 2</a></li>
                            <li><a href="#">Level 3</a></li>
                        </ul>
                    </div>
                </div>
            </aside>
            <div class="control-sidebar-bg"></div>
        </div>
        <script src="<?php echo base_url();?>/assets/js/jquery-2.2.3.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/app.min.js"></script>
    </body>
</html>
