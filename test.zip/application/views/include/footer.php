<footer class="main-footer">
    <div class="pull-right hidden-xs">
        Anything you want
    </div>
    <center><strong>Copyright &copy; 2016 <a href="#">TreasureWebs</a>.</strong></center>
</footer>