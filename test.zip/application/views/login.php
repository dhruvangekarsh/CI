<html>
    <head>
	<title>Insert Data Into Database Using CodeIgniter Form</title>
	<link href='http://fonts.googleapis.com/css?family=Marcellus' rel='stylesheet' type='text/css'/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
	<style>
	    span.error {
		color: #f00;
		font-size: 12px;
		font-weight: 600;
	    }
	</style>
    </head>
    <body>
	<div class="container">
	    <div class="col-md-4 col-sm-6">
		<?php echo form_open('account/login'); ?>
		<?php
		if (isset($message)) {
		    echo '<div class="alert alert-danger">' . $message . '</div>';
		}
		?>
		<div class="form-group">
		    <?php echo form_label('Email :'); ?> <?php echo form_error('email', '<span class="error">', '</span>'); ?>
		    <?php echo form_input(array('type' => 'email', 'id' => 'email', 'name' => 'email', 'class' => 'form-control', 'value' => $this->input->post('email'))); ?>
		</div>
		<div class="form-group">
		    <?php echo form_label('Password :'); ?> <?php echo form_error('password', '<span class="error">', '</span>'); ?>
		    <?php echo form_password(array('id' => 'password', 'name' => 'password', 'class' => 'form-control', 'value' => $this->input->post('password'))); ?>
		</div>
		<div class="form-group">
		    <?php echo form_submit(array('id' => 'submit', 'value' => 'Submit', 'class' => 'btn btn-primary')); ?>
		    <?php echo form_close(); ?>
		</div>
		<a href="<?php echo base_url().'/index.php/account/register'?>">Create an Account</a>
	    </div>
	</div>
    </body>
</html>

