<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_account extends CI_Model {

    function register($data) {
        $this->db->insert('users', $data);
        return $this->db->insert_id();
    }
	
	function login($data) {
		$query = $this->db->get_where('users', $data) or $this->db->_error_message();
		if($query->num_rows() == 1){
			return $query->row();	
		} else {
			return FALSE;
		}
    }

}