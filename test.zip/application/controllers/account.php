<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller {

    function __construct() {
	parent::__construct();
	$this->load->model('user_account');
    }

    function index() {
	if (isset($this->session->userdata['logged_in'])) {
	    $this->dashboard();
	} else {
	    $this->load->view('login');
	}
    }

    function register() {
	$this->form_validation->set_rules('username', 'Username', 'required|min_length[5]|max_length[15]');
	$this->form_validation->set_message('username', '<span>The {field} field is required.</span>');
	$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
	$this->form_validation->set_rules('password', 'Password', 'required');
	if ($this->form_validation->run() == FALSE) {
	    if (isset($this->session->userdata['logged_in'])) {
		redirect('account/test');
	    }
	    $this->load->view('register');
	} else {
	    $data = array(
		'username' => $this->input->post('username'),
		'email' => $this->input->post('email'),
		'password' => $this->input->post('password'),
	    );
	    $id = $this->user_account->register($data);
	}
    }

    function login() {
	$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
	$this->form_validation->set_rules('password', 'Password', 'required');
	if ($this->form_validation->run() == FALSE) {
	    if (isset($this->session->userdata['logged_in'])) {
		redirect('account');
	    }
	    $this->load->view('login');
	} else {
	    $data = array(
		'email' => $this->input->post('email'),
		'password' => $this->input->post('password'),
	    );
	    $user = $this->user_account->login($data);

	    if ($user !== FALSE) {
		$session_data = array(
		    'user_id' => $user->user_id,
		    'username' => $user->username
		);
		$this->session->set_userdata('logged_in', $session_data);
		redirect('account');
	    } else {
		$error['message'] = '<strong>Failure</strong> email or Password may be wrong';
		$this->load->view('account', $error);
	    }
	}
    }

    function test() {
	if (isset($this->session->userdata['logged_in'])) {
	    $this->load->view('dashboard');
	} else {
	    redirect('account');
	}
    }

    function logout() {
	if (isset($this->session->userdata['logged_in'])) {
	    $this->session->unset_userdata('logged_in');
	    $this->session->sess_destroy();
	    redirect('account');
	}
    }

    function dashboard() {
	$data = $this->session->userdata('logged_in');
	$user = $this->user_account->user_data($data);
	$this->load->view('dashboard', $user);
    }

}

?>